import React from 'react'

const UpdateAfterSaleApartment = () => {
  return (
    <div>UpdateAfterSaleApartment</div>
  )
}

export default UpdateAfterSaleApartment
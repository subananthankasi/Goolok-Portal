import React from 'react'

const UpdateRegistrationTicketApartment = () => {
  return (
    <div>UpdateRegistrationTicketApartment</div>
  )
}

export default UpdateRegistrationTicketApartment
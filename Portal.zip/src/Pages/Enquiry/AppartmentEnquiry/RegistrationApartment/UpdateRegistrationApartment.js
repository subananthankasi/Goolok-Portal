import React from 'react'

const UpdateRegistrationApartment = () => {
  return (
    <div>UpdateRegistrationApartment</div>
  )
}

export default UpdateRegistrationApartment
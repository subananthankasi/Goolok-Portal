import React from 'react'
import { TabView, TabPanel } from 'primereact/tabview';

const UpdateMandatoryApart = () => {
  return (
       <TabView>
          <TabPanel header="Current">
          </TabPanel>
          <TabPanel header="Remainder">
          </TabPanel>
        </TabView>
  )
}

export default UpdateMandatoryApart
import React from 'react'

const OtherOwnerDraftCom = () => {
  return (
    <div>OtherOwnerDraftCom</div>
  )
}

export default OtherOwnerDraftCom
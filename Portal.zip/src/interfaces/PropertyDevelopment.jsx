export const PropertyDevelopment = {
    Type: '',
};

  

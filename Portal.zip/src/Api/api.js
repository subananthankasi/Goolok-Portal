// const API_BASE_URL = "https://api.goolok.com/api"; 
// export default API_BASE_URL; 
// export const IMG_PATH = "https://api.goolok.com/uploads";



const API_BASE_URL = "https://webman.co.in/goolok/api"; 
export default API_BASE_URL; 
export const IMG_PATH = "https://webman.co.in/goolok/uploads";

// const API_BASE_URL = "https://api.rooptek.in/api"; 
// export default API_BASE_URL; 
// export const IMG_PATH = "https://api.goolok.in/uploads";

